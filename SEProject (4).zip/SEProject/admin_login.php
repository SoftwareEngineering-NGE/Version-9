<?php
require "config.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if admin exists
    $sql = "SELECT * FROM admin WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([":email" => $email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin["password"])) {
        $_SESSION["admin_id"] = $admin["id"];  // Store session correctly
        $_SESSION["role"] = "admin"; // Optional role check
        header("Location: admin_dashboard.php"); // Redirect to Admin Dashboard
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="CSS/reg.css">
</head>
<body>

<div class="container">
    <h1>Admin Login</h1>

    <?php if (isset($error_message)): ?>
        <p style="color: red;"><strong><?php echo $error_message; ?></strong></p>
    <?php endif; ?>

    <form method="POST">
        <label>Email:</label><br>
        <input type="email" name="email" required><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br>

        <button type="submit">Login</button>
    </form>

    <a href="index.php">Back to Adoption Center</a>
</div>

</body>
</html>
