<?php
session_start();
require "config.php";

// Ensure only admins can access
if (!isset($_SESSION["admin_id"])) {
    header("Location: admin_login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="CSS/admin_dashboard.css"> <!-- Admin Dashboard CSS -->
</head>
<body>

<div class="container">
    <h1>Welcome, Admin</h1>
    <p>Manage your adoption center here.</p>

    <div class="dashboard-links">
        <a href="admin_crud/dogs_read.php">Manage Dogs</a>
        <a href="admin_crud/manage_requests.php">Manage Adoption Requests</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

</body>
</html>
