<?php
require "config.php"; // Ensure database connection
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dogs Available for Adoption</title>
    <link rel="stylesheet" href="CSS/dogs.css">
</head>
<body>

<!-- Navigation Bar -->
<div class="navbar">
    <img src="images/Logo3.png" alt="Adoption Center Logo">
    <a href="index.php">Home</a>
    <a href="dogs.php">Dogs</a>
    <a href="about_us.php">About Us</a>
</div>

<!-- Search Bar -->
<div class="search-container">
    <form action="dogs.php" method="GET">
        <input type="text" name="search" placeholder="Search for a dog by breed" required>
        <button type="submit">Search</button>
    </form>
</div>

<!-- Main Content -->
<div class="container">
    <h1>Dogs Available for Adoption</h1>
    <div class="dog-list-container">

        <?php
        try {
            // Check if a search query is provided
            $search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

            // SQL query to fetch dogs from the database
            $sql = "SELECT * FROM dogs";
            if (!empty($search_query)) {
                $sql .= " WHERE breed LIKE :search";
            }

            $stmt = $pdo->prepare($sql);

            // Bind search parameter if a query exists
            if (!empty($search_query)) {
                $stmt->bindValue(':search', "%$search_query%", PDO::PARAM_STR);
            }

            $stmt->execute();
            $dogs = $stmt->fetchAll();

            // Display dogs from the database
            if ($dogs) {
                foreach ($dogs as $dog) {
                    echo '<div class="dog-container">';
                    echo '<a href="dog_description.php?id=' . $dog['id'] . '">';
                    echo '<img src="images/' . $dog['image'] . '" alt="' . htmlspecialchars($dog['name']) . '">';
                    echo '</a>';
                    echo '<div class="dog-name">' . htmlspecialchars($dog['name']) . '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No dogs found.</p>';
            }

        } catch (PDOException $e) {
            echo "Error fetching dogs: " . $e->getMessage();
        }
        ?>

    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 Adoption Center. All Rights Reserved.</p>
</div>

</body>
</html>
