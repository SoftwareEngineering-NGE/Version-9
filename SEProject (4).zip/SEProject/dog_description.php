<?php
require "config.php"; // Ensure database connection
session_start();

// Check if 'id' is passed via the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Dog not found. Please go back and select a dog.");
}

// Fetch dog details from the database
try {
    $sql = "SELECT * FROM dogs WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $_GET['id'], PDO::PARAM_INT);
    $stmt->execute();
    $dog = $stmt->fetch();

    if (!$dog) {
        die("Dog not found.");
    }
} catch (PDOException $e) {
    die("Error fetching dog details: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($dog['name']); ?> - Dog Description</title>
    <link rel="stylesheet" href="CSS/d_description.css">
</head>
<body>
<form action="request_form.php?dog_id=<?php echo $dog['id']; ?>" method="post">
<!-- Navigation Bar -->
<div class="navbar">
    <img src="images/Logo3.png" alt="Adoption Center Logo">
    <a href="index.php">Home</a>
    <a href="dogs.php">Dogs</a>
    <a href="about_us.php">About Us</a>

    <?php if (isset($_SESSION["user_id"])): ?>
        <a href="logout.php">Logout</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
</div>

<!-- Main Content -->
<div class="container">
    <h1><?php echo htmlspecialchars($dog['name']); ?></h1>

    <div class="dog-details">
        <img src="images/<?php echo htmlspecialchars($dog['image']); ?>" alt="<?php echo htmlspecialchars($dog['name']); ?>" class="dog-image">
        <p><strong>Age:</strong> <?php echo htmlspecialchars($dog['age']); ?> years</p>
        <p><strong>Breed:</strong> <?php echo htmlspecialchars($dog['breed']); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($dog['gender']); ?></p>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($dog['description']); ?></p>
    </div>

    <div class="button-container">
        <?php if (isset($_SESSION["user_id"])): ?>
            <!-- User is logged in: show adoption form -->
            <form action="request_form.php?dog_id=<?php echo $dog['id']; ?>" method="post">
                <button type="submit">Send Adoption Request</button>
            </form>
        <?php else: ?>
            <!-- User is not logged in: show login prompt -->
            <p><strong>You must <a href="login.php">log in</a> to request an adoption.</strong></p>
        <?php endif; ?>
    </div>

    <a href="dogs.php">Back to Dogs</a>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 Adoption Center. All Rights Reserved.</p>
</div>

</body>
</html>
