<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paws Adoption Center</title>
    <link rel="stylesheet" href="CSS/index.css">
</head>

<body>

<!-- Navigation Bar -->
<div class="navbar">
    <img src="images/Logo3.png" alt="Adoption Center Logo">
    <a href="index.php">Home</a>
    <a href="dogs.php">Dogs</a>
    <a href="about_us.php">About Us</a>

    <!-- Show Register button ONLY if user is NOT logged in -->
    <?php if (!isset($_SESSION["user_id"]) && !isset($_SESSION["admin_id"])): ?>
        <a href="registration.php" class="register-button">Register</a>
    <?php endif; ?>

    <!-- Show Logout button ONLY if user IS logged in -->
    <?php if (isset($_SESSION["user_id"]) || isset($_SESSION["admin_id"])): ?>
        <a href="logout.php">Logout</a>
    <?php endif; ?>
</div>

<!-- Main Content Area -->
<div class="content">
    <div class="background-container">
        <div class="background-content">
            <div class="background-text">
                Give our dogs a second chance!
                <p>Looking for a furry friend to bring into your home?</p>
                <p>Discover our lovable dogs who are eagerly waiting for their forever family.</p>
                <p>Take a step toward changing a life today and give a dog the loving home they deserve.</p>
            </div>
            <img src="images/HomePage_Dogo.jpg" alt="Adopt a Dog" class="background-image">
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 Adoption Center. All Rights Reserved.</p>
</div>

</body>
</html>
