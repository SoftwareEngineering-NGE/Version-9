<?php
require "../config.php";
session_start();

if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["request_id"], $_POST["action"])) {
    $id = (int) $_POST["request_id"];
    $action = $_POST["action"];

    if (in_array($action, ["approve", "deny"])) {
        $status = $action === "approve" ? "Approved" : "Denied";

        $sql = "UPDATE adoption_requests SET status = :status, decision_date = NOW() WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ":status" => $status,
            ":id" => $id
        ]);
    }
}

header("Location: manage_requests.php");
exit();
