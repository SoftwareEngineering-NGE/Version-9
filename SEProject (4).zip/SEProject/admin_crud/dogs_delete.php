<?php
require "../config.php";
session_start();

// Ensure only admin can access this page
if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

// Check if a valid dog ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid request. No valid dog selected.");
}

$dog_id = $_GET['id'];

try {
    // Check if the dog exists before deleting
    $check_sql = "SELECT * FROM dogs WHERE id = :id";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([":id" => $dog_id]);
    $dog = $check_stmt->fetch();

    if (!$dog) {
        die("Error: Dog not found in database.");
    }

    // Delete the dog
    $sql = "DELETE FROM dogs WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $dog_id]);

    // Redirect after deletion
    header("Location: dogs_read.php?message=Dog Deleted Successfully!");
    exit();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
