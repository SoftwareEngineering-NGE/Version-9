<?php
session_start();
require "../config.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

$sql = "SELECT ar.id, ar.status, ar.request_date, u.name AS user_name, u.email, d.name AS dog_name
        FROM adoption_requests ar
        JOIN users u ON ar.user_id = u.id
        JOIN dogs d ON ar.dog_id = d.id
        ORDER BY ar.request_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Adoption Requests</title>
    <link rel="stylesheet" href="../CSS/admin_dashboard.css">
</head>
<body>
<div class="container">
    <h1>Adoption Requests</h1>
    <a href="dogs_read.php">← Back to Dashboard</a>
    <table>
        <tr>
            <th>User</th>
            <th>Email</th>
            <th>Dog</th>
            <th>Request Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($requests as $request): ?>
            <tr>
                <td><?= htmlspecialchars($request['user_name']) ?></td>
                <td><?= htmlspecialchars($request['email']) ?></td>
                <td><?= htmlspecialchars($request['dog_name']) ?></td>
                <td><?= $request['request_date'] ?></td>
                <td><?= $request['status'] ?></td>
                <td>
                    <?php if ($request['status'] === 'Pending'): ?>
                        <form method="POST" action="update_status.php" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                            <button name="action" value="approve">Approve</button>
                            <button name="action" value="deny">Deny</button>
                        </form>
                    <?php else: ?>
                        <?= $request['status'] ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
