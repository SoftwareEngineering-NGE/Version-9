<?php
require "../config.php";
session_start();

// Ensure only admin can access this page
if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

// Check if a valid dog ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid request. No dog selected.");
}

$dog_id = $_GET['id'];

// Fetch dog details from the database
$sql = "SELECT * FROM dogs WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $dog_id]);
$dog = $stmt->fetch();

if (!$dog) {
    die("Error: Dog not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $breed = $_POST["breed"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $description = $_POST["description"];
    $image = $_POST["image"];

    try {
        $sql = "UPDATE dogs SET name = :name, breed = :breed, age = :age, gender = :gender, 
                description = :description, image = :image WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ":name" => $name,
            ":breed" => $breed,
            ":age" => $age,
            ":gender" => $gender,
            ":description" => $description,
            ":image" => $image,
            ":id" => $dog_id
        ]);

        header("Location: dogs_read.php?message=Dog Updated Successfully!");
        exit();
    } catch (PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dog</title>
    <link rel="stylesheet" href="../CSS/admin_dashboard.css">
</head>
<body>

<div class="container">
    <h1>Edit Dog</h1>

    <?php if (isset($error_message)): ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($dog['name']); ?>" required>

        <label>Breed:</label>
        <input type="text" name="breed" value="<?php echo htmlspecialchars($dog['breed']); ?>" required>

        <label>Age:</label>
        <input type="number" name="age" value="<?php echo htmlspecialchars($dog['age']); ?>" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option value="Male" <?php if ($dog['gender'] == 'Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if ($dog['gender'] == 'Female') echo 'selected'; ?>>Female</option>
        </select>

        <label>Description:</label>
        <textarea name="description" required><?php echo htmlspecialchars($dog['description']); ?></textarea>

        <label>Image Filename:</label>
        <input type="text" name="image" value="<?php echo htmlspecialchars($dog['image']); ?>" required>

        <button type="submit">Update Dog</button>
    </form>

    <a href="dogs_read.php">Back to Dog Management</a>
</div>

</body>
</html>
