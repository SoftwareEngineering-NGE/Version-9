<?php
require "../config.php";
session_start();

if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

try {
    $sql = "SELECT * FROM dogs";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $dogs = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Dogs</title>
    <link rel="stylesheet" href="../CSS/admin_dashboard.css">
</head>
<body>

<div class="container">
    <h1>Manage Dogs</h1>
    <table>
        <tr>
            <th>Name</th>
            <th>Breed</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($dogs as $dog): ?>
            <tr>
                <td><?php echo htmlspecialchars($dog['name']); ?></td>
                <td><?php echo htmlspecialchars($dog['breed']); ?></td>
                <td><?php echo htmlspecialchars($dog['age']); ?></td>
                <td><?php echo htmlspecialchars($dog['gender']); ?></td>
                <td><img src="../images/<?php echo htmlspecialchars($dog['image']); ?>" width="100"></td>
                <td>
                    <a href="dogs_update.php?id=<?php echo $dog['id']; ?>">Edit</a>
                    <a href="dogs_delete.php?id=<?php echo $dog['id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <a href="dogs_create.php">Add New Dog</a>
    <a href="../admin_dashboard.php">Back to dashboard</a>

</div>

</body>
</html>
