<?php
require "../config.php";
session_start();

// Ensure only admin can access this page
if (!isset($_SESSION["admin_id"])) {
    header("Location: ../admin_login.php");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $breed = $_POST["breed"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $description = $_POST["description"];
    $image = $_POST["image"]; // User enters filename (e.g., "dog1.jpg")

    // Check if image file exists in 'images' folder
    if (!file_exists("../images/" . $image)) {
        $error_message = "Error: Image file does not exist in the 'images' folder.";
    } else {
        try {
            $sql = "INSERT INTO dogs (name, breed, age, gender, description, image) 
VALUES (:name, :breed, :age, :gender, :description, :image)";
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                ":name" => $name,
                ":breed" => $breed,
                ":age" => $age,
                ":gender" => $gender,
                ":description" => $description,
                ":image" => $image
            ]);

            if ($result) {
                $success_message = "Dog added successfully!";
            } else {
                $error_message = "Failed to add the dog.";
            }
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add a New Dog</title>
    <link rel="stylesheet" href="../CSS/admin_dashboard.css">
</head>
<body>

<div class="container">
    <h1>Add a New Dog</h1>

    <?php if (isset($error_message)): ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php elseif (isset($success_message)): ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Breed:</label>
        <input type="text" name="breed" required>

        <label>Age:</label>
        <input type="number" name="age" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>

        <label>Description:</label>
        <textarea name="description" required></textarea>

        <label>Image Filename:</label>
        <input type="text" name="image" placeholder="dog1.jpg" required>

        <button type="submit">Add Dog</button>
    </form>

    <a href="dogs_read.php">Back to Dog Management</a>
</div>

</body>
</html>
